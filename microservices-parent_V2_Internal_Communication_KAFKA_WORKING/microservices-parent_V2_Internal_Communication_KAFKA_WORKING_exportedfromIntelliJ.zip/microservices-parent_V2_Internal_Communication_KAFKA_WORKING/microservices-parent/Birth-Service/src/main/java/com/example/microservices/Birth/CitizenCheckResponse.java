package com.example.microservices.Birth;

public record CitizenCheckResponse(Boolean isExist) {
}
