package com.example.microservices.Birth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BirthApplicationTests {

	@Test
	void contextLoads() {
	}

}
